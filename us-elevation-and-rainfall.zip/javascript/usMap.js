// best projection is d3.geoAlbers()
import * as d3 from "d3";

var usPromise = d3.json("../data/us-states.json");
var drawUs = function (states) {
  var usPath = d3.geoPath().projection(d3.geoAlbers());
  var usSvg = d3.select("#usMap");
  usSvg
    .append("g")
    .selectAll("path")
    .data(states.features)
    .enter()
    .append("path")
    .attr("d", usPath)
    .style("fill", "white");
};
var usFail = function (error) {
  console.log("error: ", error);
};
//promise2.then(success2, fail2);

var usPointPromise = d3.csv("../data/contiguous.csv");
var usPointSuccess = function (stations) {
  console.log("station data: ", stations);
  createUsDots(stations);
};
var usPointFail = function (error) {
  console.log("error: ", error);
};
// pointPromise2.then(pointSuccess2, pointFail2);

var createUsDots = function (stations) {
  var usProjection = d3.geoAlbers();
  var maxElevation = d3.max(stations, function (station) {
    return Number(station.elevation);
  });
  var minElevation = d3.min(stations, function (station) {
    return Number(station.elevation);
  });
  var heightScale = d3
    .scaleSequential()
    .domain([minElevation, maxElevation])
    .interpolator(d3.interpolateGreys);
  var maxRain = d3.max(stations, function (station) {
    return Number(station.rain);
  });
  var minRain = d3.min(stations, function (station) {
    return Number(station.rain);
  });
  var rainScale = d3
    .scaleSequential()
    .domain([minRain, maxRain])
    .interpolator(d3.interpolateBlues);

  d3.select("#usMap")
    .append("g")
    .selectAll("circle")
    .data(stations)
    .enter()
    .append("circle")
    .attr("cx", function (station) {
      return usProjection([station.longitude, station.latitude])[0];
    })
    .attr("cy", function (station) {
      return usProjection([station.longitude, station.latitude])[1];
    })
    .attr("r", 4)
    .style("stroke", function (stations) {
      return heightScale(stations.elevation);
    })
    .style("stroke-width", 3.5)
    .style("fill", function (stations) {
      return rainScale(stations.rain);
    })
    .on("mouseover", function (eventData, stations) {
      var target = d3.select("#usDetail");
      target.select("#name").text("Station: " + stations.name);
      target
        .select("#elevation")
        .text("Meters Above Sea Level: " + stations.elevation);
      target
        .select("#rain")
        .text("Average Yearly Rainy Days: " + Number(stations.rain) / 10);
    });
};
var usPromises = Promise.all([usPromise, usPointPromise]);

var allUsSuccess = function (usArray) {
  console.log("map: ", usArray[0]);
  console.log("stations: ", usArray[1]);
  var map = usArray[0];
  var stations = usArray[1];
  drawUs(map);
  createUsDots(stations);
};
var allUsFail = function (error) {
  console.log("error: ", error);
};
usPromises.then(allUsSuccess, allUsFail);
