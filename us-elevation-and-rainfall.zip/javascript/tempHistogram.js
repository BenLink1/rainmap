import * as d3 from "d3";
import { geoOrthographicRaw } from "d3";

var tempPromise = d3.csv("../data/contiguous.csv");

var tempSuccess = function (stations) {
  var screen = { width: 600, height: 400 };
  var margins = { top: 50, bottom: 50, left: 50, right: 50 };
  var graph = {
    width: screen.width - margins.left - margins.right,
    height: screen.height - margins.top - margins.bottom
  };

  console.log("station data: ", stations);
  var tempGenerator = d3
    .bin()
    .value(function (station) {
      return Number(station.temp) / 10;
    })
    .thresholds(29);

  var tempData = tempGenerator(stations);
  // var rainNames = rainData.map(makeBinName);
  var tempBinScale = d3.scaleLinear().domain([0, 100]).range([0, graph.width]);

  var maxTemp = d3.max(tempData, function (bin) {
    return bin.length;
  });

  var frequencyTempScale = d3
    .scaleLinear()
    .domain([0, maxTemp])
    .range([graph.height, 0]);

  var target = "#svgTemp";
  console.log("tempData: ", tempData);

  var g = d3
    .select(target)
    .append("g")
    .attr("id", "theRealTempGraph")
    .attr("transform", "translate(" + margins.left + "," + margins.top + ")");
  drawBarChartTemp(tempData, graph, target, tempBinScale, frequencyTempScale);
  createLabelsTemp(graph, target, margins, screen);
  createTempAxes(
    screen,
    margins,
    graph,
    target,
    tempBinScale,
    frequencyTempScale
  );
};

var tempFail = function (error) {
  console.log("error: ", error);
};
tempPromise.then(tempSuccess, tempFail);

var drawBarChartTemp = function (
  tempData,
  graph,
  target,
  tempBinScale,
  frequencyTempScale
) {
  var rectangles = d3
    .select(target)
    .select("#theRealTempGraph")
    .selectAll("rect")
    .data(tempData)
    .enter()
    .append("rect")
    .attr("x", function (bin) {
      return tempBinScale(bin.x0);
    })
    .attr("width", function (bin) {
      return tempBinScale(bin.x1 - bin.x0);
    })
    .attr("y", function (bin) {
      return frequencyTempScale(bin.length);
    })
    .attr("height", function (bin) {
      return graph.height - frequencyTempScale(bin.length);
    })
    .style("fill", "black")
    .on("mouseover", function (eventData, bin) {
      var target = d3.select("#tempDetail");
      target
        .select("#tempFrequency")
        .text("Number of Stations: " + Number(bin.length));
      target
        .select("#tempRange")
        .text("Range: " + bin.x0 + "-" + bin.x1 + " Degrees Farenheit");
    });
};
var createLabelsTemp = function (graph, target, margins, screen) {
  var labels = d3.select(target).append("g").classed("labels", true);

  labels
    .append("text")
    .text("Distribition of Average Temperature in the US")
    .classed("title", true)
    .attr("text-anchor", "middle")
    .attr("x", graph.width / 2)
    .attr("y", margins.top / 2);
  labels
    .append("text")
    .text("Average Degrees Farenheit")
    .classed("label", true)
    .attr("text-anchor", "middle")
    .attr("x", graph.width / 2)
    .attr("y", screen.height - 10);
  labels
    .append("text")
    .text("Number of Stations")
    .classed("title", true)
    .attr("text-anchor", "middle")
    .attr("transform", "rotate(90)");
};
var createTempAxes = function (screen, margins, graph, target, xScale, yScale) {
  var xAxis = d3.axisBottom(xScale);
  var yAxis = d3.axisLeft(yScale).ticks(10);

  var axes = d3.select(target).append("g").classed("axes", true);
  axes
    .append("g")
    .attr(
      "transform",
      "translate(" + margins.left + "," + (margins.top + graph.height) + ")"
    )
    .call(xAxis)
    .classed("xAxis", true);
  axes
    .append("g")
    .attr("transform", "translate(" + margins.left + "," + margins.top + ")")
    .call(yAxis)
    .classed("yAxis", true);
};
