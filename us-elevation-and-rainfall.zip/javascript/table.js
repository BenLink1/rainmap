import * as d3 from "d3";

var tablePromise = d3.csv("../data/contiguous.csv");
var success1 = function (weather) {
  console.log("station data: ", weather);
  createTable1(weather);
  d3.select("#latitude").on("click", function () {
    clearTable();
    console.log("clocked");
    weather.sort(function (stationA, stationB) {
      if (Number(stationA.latitude) > Number(stationB.latitude)) {
        return -1;
      }
      if (Number(stationA.latitude) === Number(stationB.latitude)) {
        return 0;
      }
      if (Number(stationA.latitude) < Number(stationB.latitude)) {
        return 1;
      }
    });
    console.log("sorted data: ", weather);
    createTable1(weather);
  });
  d3.select("#longitude").on("click", function () {
    clearTable();
    console.log("clocked");
    weather.sort(function (stationA, stationB) {
      if (Number(stationA.longitude) > Number(stationB.longitude)) {
        return -1;
      }
      if (Number(stationA.longitude) === Number(stationB.longitude)) {
        return 0;
      }
      if (Number(stationA.longitude) < Number(stationB.longitude)) {
        return 1;
      }
    });
    console.log("sorted data: ", weather);
    createTable1(weather);
  });
  d3.select("#elevation").on("click", function () {
    clearTable();
    console.log("clocked");
    weather.sort(function (stationA, stationB) {
      if (Number(stationA.elevation) > Number(stationB.elevation)) {
        return -1;
      }
      if (Number(stationA.elevation) === Number(stationB.elevation)) {
        return 0;
      }
      if (Number(stationA.elevation) < Number(stationB.elevation)) {
        return 1;
      }
    });
    console.log("sorted data: ", weather);
    createTable1(weather);
  });
  d3.select("#temp").on("click", function () {
    clearTable();
    console.log("clocked");
    weather.sort(function (stationA, stationB) {
      if (Number(stationA.temp) > Number(stationB.temp)) {
        return -1;
      }
      if (Number(stationA.temp) === Number(stationB.temp)) {
        return 0;
      }
      if (Number(stationA.temp) < Number(stationB.temp)) {
        return 1;
      }
    });
    console.log("sorted data: ", weather);
    createTable1(weather);
  });
  d3.select("#rain").on("click", function () {
    clearTable();
    console.log("clocked");
    weather.sort(function (stationA, stationB) {
      if (Number(stationA.rain) > Number(stationB.rain)) {
        return -1;
      }
      if (Number(stationA.rain) === Number(stationB.rain)) {
        return 0;
      }
      if (Number(stationA.rain) < Number(stationB.rain)) {
        return 1;
      }
    });
    console.log("sorted data: ", weather);
    createTable1(weather);
  });
};
var fail1 = function (error) {
  console.log("error,", error);
};
tablePromise.then(success1, fail1);
var createTable1 = function (weather) {
  var rows1 = d3
    .select("#table1 tbody")
    .selectAll("tr")
    .data(weather)
    .enter()
    .append("tr");
  rows1.append("td").text(function (weather) {
    return weather.name;
  });
  rows1.append("td").text(function (weather) {
    return weather.id;
  });
  rows1.append("td").text(function (weather) {
    return weather.latitude;
  });
  rows1.append("td").text(function (weather) {
    return weather.longitude;
  });
  rows1.append("td").text(function (weather) {
    return weather.elevation;
  });
  rows1.append("td").text(function (weather) {
    return weather.temp / 10;
  });
  rows1.append("td").text(function (weather) {
    return weather.rain / 10;
  });
};
var clearTable = function () {
  d3.selectAll("tbody tr").remove();
};
