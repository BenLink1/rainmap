import * as d3 from "d3";

var waPromise = d3.json("../data/washington.json");
var waPointPromise = d3.csv("../data/washington.csv");
var waPromises = Promise.all([waPromise, waPointPromise]);
var drawWa = function (states) {
  var waProjection = d3.geoAlbers().scale(7000).translate([2400, 1700]);
  var waPath = d3.geoPath().projection(waProjection);
  var waSvg = d3.select("#waMap");
  waSvg
    .append("g")
    .selectAll("path")
    .data(states.features)
    .enter()
    .append("path")
    .attr("d", waPath)
    .style("fill", "green");
};
var allWaSuccess = function (usArray) {
  console.log("map: ", usArray[0]);
  console.log("stations: ", usArray[1]);
  var map = usArray[0];
  var stations = usArray[1];
  drawWa(map);
  createWaDots(stations);
};
var allWaFail = function (error) {
  console.log("error: ", error);
};
waPromises.then(allWaSuccess, allWaFail);

var createWaDots = function (stations) {
  var waProjection = d3.geoAlbers().scale(7000).translate([2400, 1700]);
  var maxElevation = d3.max(stations, function (station) {
    return Number(station.elevation);
  });
  var minElevation = d3.min(stations, function (station) {
    return Number(station.elevation);
  });
  var heightScale = d3
    .scaleSequential()
    .domain([minElevation, maxElevation])
    .interpolator(d3.interpolateGreys);
  var maxRain = d3.max(stations, function (station) {
    return Number(station.rain);
  });
  var minRain = d3.min(stations, function (station) {
    return Number(station.rain);
  });
  var rainScale = d3
    .scaleSequential()
    .domain([minRain, maxRain])
    .interpolator(d3.interpolateBlues);

  d3.select("#waMap")
    .append("g")
    .selectAll("circle")
    .data(stations)
    .enter()
    .append("circle")
    .attr("cx", function (station) {
      return waProjection([station.longitude, station.latitude])[0];
    })
    .attr("cy", function (station) {
      return waProjection([station.longitude, station.latitude])[1];
    })
    .attr("r", 5)
    .style("stroke", function (stations) {
      return heightScale(stations.elevation);
    })
    .style("stroke-width", 4)
    .style("fill", function (stations) {
      return rainScale(stations.rain);
    })
    .on("mouseover", function (eventData, stations) {
      console.log("rain: ", Number(stations.rain) / 10);
      var target = d3.select("#waDetail");
      target.select("#name").text("Station: " + stations.name);
      target
        .select("#elevation")
        .text("Meters Above Sea Level: " + stations.elevation);
      target
        .select("#rain")
        .text("Average Yearly Rainy Days: " + Number(stations.rain) / 10);
    });
};
