import * as d3 from "d3";
import { geoOrthographicRaw } from "d3";

var rainPromise = d3.csv("../data/contiguous.csv");

var rainSuccess = function (stations) {
  var screen = { width: 600, height: 400 };
  var margins = { top: 50, bottom: 50, left: 50, right: 50 };
  var graph = {
    width: screen.width - margins.left - margins.right,
    height: screen.height - margins.top - margins.bottom
  };

  console.log("station data: ", stations);
  var rainGenerator = d3
    .bin()
    .value(function (station) {
      return Number(station.rain) / 10;
    })
    .thresholds(29);

  var rainData = rainGenerator(stations);
  // var rainNames = rainData.map(makeBinName);
  var rainBinScale = d3.scaleLinear().domain([0, 240]).range([0, graph.width]);

  var maxRains = d3.max(rainData, function (bin) {
    return bin.length;
  });

  var frequencyRainScale = d3
    .scaleLinear()
    .domain([0, maxRains])
    .range([graph.height, 0]);

  var target = "#svgRain";
  console.log("rainData: ", rainData);

  var g = d3
    .select(target)
    .append("g")
    .attr("id", "theRealRainGraph")
    .attr("transform", "translate(" + margins.left + "," + margins.top + ")");
  drawBarChartrain(rainData, graph, target, rainBinScale, frequencyRainScale);
  createLabelsRain(graph, target, margins, screen);
  createRainAxes(
    screen,
    margins,
    graph,
    target,
    rainBinScale,
    frequencyRainScale
  );
};

var rainFail = function (error) {
  console.log("error: ", error);
};
rainPromise.then(rainSuccess, rainFail);

var drawBarChartrain = function (
  rainData,
  graph,
  target,
  rainBinScale,
  frequencyRainScale
) {
  var rectangles = d3
    .select(target)
    .select("#theRealRainGraph")
    .selectAll("rect")
    .data(rainData)
    .enter()
    .append("rect")
    .attr("x", function (bin) {
      return rainBinScale(bin.x0);
    })
    .attr("width", function (bin) {
      return rainBinScale(bin.x1 - bin.x0);
    })
    .attr("y", function (bin) {
      return frequencyRainScale(bin.length);
    })
    .attr("height", function (bin) {
      return graph.height - frequencyRainScale(bin.length);
    })
    .style("fill", "blue")
    .on("mouseover", function (eventData, bin) {
      var target = d3.select("#rainDetail");
      target
        .select("#rainFrequency")
        .text("Number of Stations: " + Number(bin.length));
      target
        .select("#rainRange")
        .text("Range: " + bin.x0 + "-" + bin.x1 + " Rainy Days");
    });
};
var createLabelsRain = function (graph, target, margins, screen) {
  var labels = d3.select(target).append("g").classed("labels", true);

  labels
    .append("text")
    .text("Distribition of Rainy Days in the US")
    .classed("title", true)
    .attr("text-anchor", "middle")
    .attr("x", graph.width / 2)
    .attr("y", margins.top / 2);
  labels
    .append("text")
    .text("Days Per Year with Rain")
    .classed("label", true)
    .attr("text-anchor", "middle")
    .attr("x", graph.width / 2)
    .attr("y", screen.height - 10);
  labels
    .append("text")
    .text("Number of Stations")
    .classed("title", true)
    .attr("text-anchor", "middle")
    .attr("transform", "rotate(90)");
};
var createRainAxes = function (screen, margins, graph, target, xScale, yScale) {
  var xAxis = d3.axisBottom(xScale);
  var yAxis = d3.axisLeft(yScale).ticks(10);

  var axes = d3.select(target).append("g").classed("axes", true);
  axes
    .append("g")
    .attr(
      "transform",
      "translate(" + margins.left + "," + (margins.top + graph.height) + ")"
    )
    .call(xAxis)
    .classed("xAxis", true);
  axes
    .append("g")
    .attr("transform", "translate(" + margins.left + "," + margins.top + ")")
    .call(yAxis)
    .classed("yAxis", true);
};
